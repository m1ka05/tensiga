Efficient isogeometric Galerkin method for IEVP
==============================================================================

This project aims towards ...

.. toctree::
   :maxdepth: 1

   Documentation <documentation.rst>
   Code coverage <coverage_html_report/index.html#http://>


:ref:`genindex`
